﻿using System;
using System.Windows.Forms;


namespace Cselian.Sublime
{

	public partial class Popup : Form
	{
        

		public Popup()
		{
			InitializeComponent();
			tmrTick.Interval = 5000;
		}

		// timer.Elapsed is on a different thread, so is forms timer
		private string text;

		public void SetText(string text)
		{
			this.text = text;
		}

		private void tmrTick_Tick(object sender, EventArgs e)
		{
			if (text != null)
			{
                lblMsg.Text = text;
				Width = lblMsg.Width + 2 * lblMsg.Left;
                Random rndnumber = new Random(Guid.NewGuid().GetHashCode());
                int myrndnumber = rndnumber.Next(0, (Screen.PrimaryScreen.Bounds.Width - Width + 1));
                Random rndnumber2 = new Random(Guid.NewGuid().GetHashCode());
                int myrndnumber2 = rndnumber2.Next(0, (Screen.PrimaryScreen.Bounds.Height - 30));
                Left = (Screen.PrimaryScreen.Bounds.Width - Width) -myrndnumber;
                Top = myrndnumber2;
                text = null;
				Show();
			}
			else if (Visible)
			{
				Hide();
			}
		}

		public void SetTimeOn(int duration)
		{
			tmrTick.Interval = duration;
		}

               

      private void Popup_Load(object sender, EventArgs e)
      {
          

      }


        private void Popup_MouseHover (object sender, EventArgs e)
        {
            //lblMsg.Text = "Testing...";
            Hide();
        }


	}
}
