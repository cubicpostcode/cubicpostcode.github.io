You only need to double-click on any Windows computer the file named: "startall.bat".
It will populate the screen instantiating many times the execuatble.
You can change the text files to set time intervals, the dictionary of messages and duration displayed.
It is open source and free software adapted from a another project on github.
You can check all the code and compile it yourself using the source code folder: "src".