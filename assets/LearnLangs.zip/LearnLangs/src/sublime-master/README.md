sublime
=======

Show subliminal messages onscreen
http://en.wikipedia.org/wiki/Subliminal_stimuli

Subliminal messages are a form of Nootropic and work on the subconscious mind.

Nootropic: Any drug or system that increases brain function / level of consciousness / attitude etc

To get started, download Cselian.Sublime.exe

Changelog
----------
- 22-May-14: fixed timer threading issue
- 20-May-14: added textbox, save and popup form
