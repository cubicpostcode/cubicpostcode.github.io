﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Cselian.Sublime
{
	public partial class Main : Form
	{
		private string[] Lines;
		private int LineIndex;
		private int secsLeft = 10;

		private const string MessagesFile = "sublime-messages.txt";
		private const string IntervalFile = "sublime-interval.txt";
		private const string TimeOnFile = "sublime-timeon.txt";

		public Main()
		{
			InitializeComponent();

			if (File.Exists(MessagesFile)) txtLines.Text = File.ReadAllText(MessagesFile, Encoding.Default);
			Lines = txtLines.Text.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
			
			popup = new Popup();
           

            if (File.Exists(TimeOnFile))
			{
				txtTimeOn.Text = File.ReadAllText(TimeOnFile);
				popup.SetTimeOn(int.Parse(txtTimeOn.Text));
			}

			if (File.Exists(IntervalFile)) secsLeft = int.Parse(File.ReadAllText(IntervalFile));
			txtInterval.Text = secsLeft.ToString();
			timer = new System.Timers.Timer(secsLeft * 1000);
			timer.Enabled = true;
			timer.Elapsed += timer_Elapsed;
			timer_Elapsed(null, null);

        }

		// Forms.Timer doesnt tick when its minimized
		private System.Timers.Timer timer;
		Popup popup; // lets reuse the same form

		private void txtInterval_TextChanged(object sender, EventArgs e)
		{
			if (timer == null) return;
			secsLeft = int.Parse(txtInterval.Text);
			timer.Interval = secsLeft * 1000;
			File.WriteAllText(IntervalFile, txtInterval.Text);
		}

		private void txtTimeOn_TextChanged(object sender, EventArgs e)
		{
			popup.SetTimeOn(int.Parse(txtTimeOn.Text));
			File.WriteAllText(TimeOnFile, txtTimeOn.Text);
		}

		private void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
		{
			if (chkPause.Checked) return;

            var line = Lines[LineIndex]; 

            popup.SetText(line);


            Random rndnumberline = new Random(Guid.NewGuid().GetHashCode());
            int myrndnumberline = rndnumberline.Next(0, Lines.Length);

            LineIndex = myrndnumberline;

            secsLeft = (int)Math.Ceiling(timer.Interval / 1000);
		}

		private void btnSave_Click(object sender, System.EventArgs e)
		{
			Lines = txtLines.Text.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
			File.WriteAllText(MessagesFile, txtLines.Text);
		}

		private void tmrSecs_Tick(object sender, EventArgs e)
		{
			if (chkPause.Checked) return;
			secsLeft -= 1;
			lblSecsLeft.Text = secsLeft.ToString() + " left";
		}

        private void txtLines_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
